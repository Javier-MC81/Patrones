//
//  Constants.swift
//  DragonBallBase
//
//  Created by Pedro Martín on 12/1/23.
//

import Foundation

class Constants {
    static var api_base_url = "https://dragonball.keepcoding.education/api/"
}
